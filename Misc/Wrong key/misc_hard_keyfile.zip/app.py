#!/usr/bin/env python3
import json, base64, sys, os

def xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])

def main():
    try:
        cfg = json.load(open("settings.json","r",encoding="utf-8"))
    except Exception:
        print("Error: settings.json missing/bad")
        sys.exit(1)

    if cfg.get("mode") != "training":
        print("This tool only prints output in training mode.")
        sys.exit(1)

    key_path = cfg.get("key_path","")
    if not key_path or not os.path.exists(key_path):
        print("Key file not found.")
        print("Hint: check settings.json -> key_path")
        sys.exit(1)

    try:
        key = base64.b64decode(open(key_path,"rb").read().strip())
    except Exception:
        print("Bad key file.")
        sys.exit(1)

    try:
        blob = base64.b64decode(cfg["blob_b64"])
    except Exception:
        print("Bad blob_b64.")
        sys.exit(1)

    # decrypt: blob_b64 -> bytes -> XOR -> base64(flag) -> decode
    step1 = xor_bytes(blob, key)
    try:
        flag = base64.b64decode(step1).decode()
    except Exception:
        print("Decryption failed.")
        sys.exit(1)

    print(flag)

if __name__ == "__main__":
    main()
