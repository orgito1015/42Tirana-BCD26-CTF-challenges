# Misc (Hard) — "Wrong Key Path"

A trainer tool was packaged for a drill. It should print the flag **only** when:
- the app is in `training` mode
- it can find the correct key file

The tool works, but the deployment configuration is wrong.

## Goal
Fix the misconfiguration (no code edits needed), run the app, and get the flag.

## Run
./run.sh

## Hints
- Look at `settings.json`
- One key file is a decoy
- If decryption fails, you likely used the wrong key
