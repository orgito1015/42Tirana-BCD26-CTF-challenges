#!/usr/bin/env python3
import json, base64, sys

def main():
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        print("Error: cannot read config.json")
        sys.exit(1)

    # Misconfiguration: app expects enable_flag, but config uses enable_flga
    if not cfg.get("enable_flag", False):
        print("Feature disabled.")
        print("Hint: check config.json keys.")
        sys.exit(1)

    try:
        flag = base64.b64decode(cfg["flag_b64"]).decode()
    except Exception:
        print("Error: bad flag_b64")
        sys.exit(1)

    print(flag)

if __name__ == "__main__":
    main()
