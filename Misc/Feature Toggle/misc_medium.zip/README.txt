# Misc (Medium) — "Feature Toggle"

A tiny internal tool has a feature flag that controls whether the output is shown.
The tool is correctly coded, but the **configuration is wrong**.

## Goal
Fix the misconfiguration in `config.json`, then run the program to print the flag.

## Run
./run.sh

## Hint
- This is about a *misconfigured key / option*.
