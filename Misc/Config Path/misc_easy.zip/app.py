#!/usr/bin/env python3
import os, sys

def main():
    # Misconfiguration: default points to a non-existent path
    cfg_path = os.environ.get("APP_CONFIG", "./config/app.config")  # <- wrong extension
    if not os.path.exists(cfg_path):
        print("Error: config not found.")
        print("Hint: APP_CONFIG environment variable may help.")
        sys.exit(1)

    flag = None
    with open(cfg_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line.startswith("FLAG="):
                flag = line.split("=", 1)[1]
                break

    if not flag:
        print("Error: FLAG not set in config.")
        sys.exit(1)

    print(flag)

if __name__ == "__main__":
    main()
