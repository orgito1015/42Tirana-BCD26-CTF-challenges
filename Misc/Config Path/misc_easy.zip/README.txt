# Misc (Easy) — "Config Path"

You found a small tool used in the 42 Tirana lab, but it fails to start.

## Goal
Fix the misconfiguration, then run the program to print the flag.

## Run
./run.sh

## Notes
- No brute force needed.
- This is a configuration issue.
